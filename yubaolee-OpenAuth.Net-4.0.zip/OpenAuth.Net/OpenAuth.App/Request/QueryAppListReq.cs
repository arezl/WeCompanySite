﻿namespace OpenAuth.App.Request
{
    public class QueryAppListReq : PageReq
    {

    }
}
