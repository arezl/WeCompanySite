﻿namespace OpenAuth.App.Request
{
    public class QueryResourcesReq : PageReq
    {
        /// <summary>
        /// TypeID
        /// </summary>
        public string TypeId { get; set; }

    }
}
