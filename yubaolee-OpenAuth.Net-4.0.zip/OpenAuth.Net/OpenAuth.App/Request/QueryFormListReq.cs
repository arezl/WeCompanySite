﻿namespace OpenAuth.App.Request
{
    public class QueryFormListReq : PageReq
    {
        public string orgId { get; set; }
    }
}
