﻿namespace OpenAuth.App.Request
{
    public class IdPageReq :PageReq
    {
        public string id { get; set; }
    }
}
