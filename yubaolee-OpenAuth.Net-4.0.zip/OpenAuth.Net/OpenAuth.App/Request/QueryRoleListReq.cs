﻿namespace OpenAuth.App.Request
{
    public class QueryRoleListReq : PageReq
    {
        public string orgId { get; set; }
    }
}
