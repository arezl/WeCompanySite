﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OpenAuth.UnitTest
{
    /// <summary>
    /// TestLogin 的摘要说明
    /// </summary>
    [TestClass]
    public class TestLogin
    {
        

        [TestMethod]
        public void Test()
        {
            
        }
    }
}
